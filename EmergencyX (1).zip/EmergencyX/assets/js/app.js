const $ = s => document.querySelector(s), esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
let token = sessionStorage.getItem("emx_token"), me = JSON.parse(sessionStorage.getItem("emx_user") || "null"), ws, retry = 1000, map, layers = {}, trips = [], hospitals = [], junctions = [], alerts = [], unread = 0, sim = null, busy = false, origin = null, watch = null, lastSent = 0, lastFit = null, form = { hosp: null, cat: "URGENT" };
const fmt = d => d ? new Date(d).toLocaleString() : "–", km = m => m == null ? "–" : (m / 1000).toFixed(2) + " km", mins = s => s == null ? "–" : Math.round(s / 60) + " min";
async function api(path, method = "GET", body) {
  let r; try { r = await fetch("/api" + path, { method, headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) }, body: body ? JSON.stringify(body) : undefined }); }
  catch { throw new Error("Backend unreachable. Start it with run_backend.bat"); }
  const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || j.detail || ("HTTP " + r.status)); return j;
}
function note(msg, tid) { unread++; $("#unread").textContent = unread; $("#log").insertAdjacentHTML("afterbegin", `<div class="item">${new Date().toLocaleTimeString()} ${tid ? "[" + esc(tid) + "] " : ""}${esc(msg)}</div>`); }
function dialog(html, onSubmit) {
  $("#dform").innerHTML = html + `<div class="row"><button value="ok" class="green">OK</button><button value="x" formnovalidate>Close</button></div><div class="err" id="derr"></div>`;
  $("#dform").onsubmit = async e => { if (e.submitter?.value !== "ok" || !onSubmit) return; e.preventDefault(); try { await onSubmit(new FormData($("#dform"))); $("#dlg").close(); } catch (x) { $("#derr").textContent = x.message; } };
  $("#dlg").showModal();
}
function loginDialog(role) {
  dialog(`<h3>Sign in${role ? " (" + role + ")" : ""}</h3><p>Local demo accounts are listed in README.md.</p><label>Username</label><input name="u" required><label>Password</label><input name="p" type="password" required>`, async f => {
    const j = await api("/auth/login", "POST", { username: f.get("u"), password: f.get("p") });
    if (role && j.user.role !== role && j.user.role !== "admin") throw new Error("This account is not a " + role + " account");
    token = j.token; me = j.user; sessionStorage.setItem("emx_token", token); sessionStorage.setItem("emx_user", JSON.stringify(me)); await enter();
  });
}
document.addEventListener("click", e => {
  const b = e.target.closest("button"); if (!b) return;
  if (b.dataset.role) return me ? enter() : loginDialog(b.dataset.role);
  const a = b.dataset.act;
  if (a === "how") dialog(`<h3>How it works</h3><p>1. Driver picks a hospital and starts a trip (route from OSRM; clearly labelled simulated if unavailable).<br>2. Police see junction alerts on the route and acknowledge or mark them managed.<br>3. Hospital sees ETA and confirms arrival.<br>All updates sync over WebSockets. Nothing here controls real traffic lights.</p>`);
  if (a === "start") me ? enter() : loginDialog("driver");
  if (a === "request") dialog(`<h3>Request a demo</h3><label>Name</label><input name="n" required><label>Email</label><input name="e" type="email" required><label>Organisation</label><input name="o">`, async f => { await api("/demo-requests", "POST", { name: f.get("n"), email: f.get("e"), organisation: f.get("o") }); alert("Request saved."); });
});
$("#logout").onclick = () => { sessionStorage.clear(); location.reload(); };
$("#bell").onclick = () => { unread = 0; $("#unread").textContent = 0; };
function connect() {
  if (!token) return; ws = new WebSocket((location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/ws/trips/all?token=" + encodeURIComponent(token));
  ws.onopen = () => { retry = 1000; $("#conn").className = "pill ok"; $("#conn").textContent = "● connected"; };
  ws.onmessage = e => { const m = JSON.parse(e.data); note(m.type.replace(/_/g, " "), (m.trip || m.alert || {}).id || (m.alert || {}).trip_id); refresh(); };
  ws.onclose = () => { $("#conn").className = "pill bad"; $("#conn").textContent = "● reconnecting…"; note("Connection lost, retrying"); if (token) setTimeout(connect, retry = Math.min(retry * 2, 15000)); };
}
function initMap() {
  if (map) return; map = L.map("map").setView([51.507, -0.11], 12); L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap" }).addTo(map);
  layers = { g: L.layerGroup().addTo(map) };
  map.on("mousemove", e => $("#coords").textContent = e.latlng.lat.toFixed(4) + ", " + e.latlng.lng.toFixed(4));
  map.on("click", e => { if (me.role === "driver") { origin = e.latlng; $("#origin") && ($("#origin").value = origin.lat.toFixed(5) + "," + origin.lng.toFixed(5)); } });
}
const mk = (e, ll, tip) => L.marker(ll, { icon: L.divIcon({ html: e, className: "", iconSize: [24, 24], iconAnchor: [12, 12] }) }).bindTooltip(tip).addTo(layers.g);
function draw(sel) {
  layers.g.clearLayers(); hospitals.forEach(h => mk("🏥", [h.lat, h.lon], h.name)); junctions.forEach(j => mk("🔶", [j.lat, j.lon], j.name));
  trips.filter(t => ["ACTIVE", "PAUSED"].includes(t.status)).forEach(t => { const on = !sel || sel === t.id;
    if (t.route) L.polyline(t.route, { color: t.route_source === "osrm" ? "#3b82f6" : "#f5a524", dashArray: t.route_source === "osrm" ? null : "6", opacity: on ? 1 : .3 }).bindTooltip(t.route_source === "osrm" ? "Road route (OSRM)" : "SIMULATED straight line").addTo(layers.g);
    mk("🚑", [t.cur_lat, t.cur_lon], t.id); mk("🟢", [t.origin_lat, t.origin_lon], "Origin"); });
  const focus = trips.find(t => t.id === sel) || trips.find(t => ["ACTIVE", "PAUSED"].includes(t.status));
  if (focus?.route && (sel || focus.id !== lastFit)) { map.fitBounds(L.polyline(focus.route).getBounds(), { padding: [30, 30] }); lastFit = focus.id; }
}
const tripCard = (t, extra = "") => `<div class="item"><b>${esc(t.id)}</b> <span class="st ${t.status}">${t.status}</span> ${t.is_demo ? '<span class="demo">DEMO</span>' : ""}<br>AMB ${t.ambulance_id} → ${esc((hospitals.find(h => h.id === t.hospital_id) || {}).name)}<br>${km(t.remaining_m)} left · ${mins(t.duration_s)} planned · ETA ${fmt(t.eta)} · ${esc(t.category)} · ${esc(t.case_ref)}<br>Route: ${t.route_source === "osrm" ? "road network (OSRM)" : '<span class="demo">SIMULATED</span>'} ${extra}</div>`;
async function refresh() {
  if (!me) return;
  try {
    [trips, alerts] = [(await api("/trips")).data, (await api("/alerts")).data]; const s = (await api("/analytics/summary")).data;
    $("#stats").innerHTML = [["Active trips", s.active_trips], ["Tracked ambulances", s.tracked_ambulances], ["Incoming arrivals", s.incoming_arrivals], ["Pending alerts", s.pending_alerts], ["Completed", s.completed_trips], ["Avg journey", mins(s.avg_journey_s)], ["Avg ack", s.avg_ack_s == null ? "–" : Math.round(s.avg_ack_s) + " s"], ["Delay", mins(s.total_delay_s)]].map(([k, v]) => `<div class="stat">${k}<b>${v}</b></div>`).join("") + (s.includes_demo_data ? '<span class="demo">DEMO DATA included</span>' : "");
    renderPanel(); renderAlerts(); draw();
  } catch (e) { note("Refresh failed: " + e.message); }
}
function renderAlerts() {
  const jn = id => (junctions.find(j => j.id === id) || {}).name || "–";
  $("#alerts").innerHTML = alerts.filter(a => trips.some(t => t.id === a.trip_id && ["ACTIVE", "PAUSED"].includes(t.status))).map(a => `<div class="item"><b>${esc(a.type)}</b> ${esc(jn(a.junction_id))} <span class="st ${a.status}">${a.status}</span> · ${esc(a.trip_id)} · prio ${a.priority}<br>${a.ack_at ? "Ack " + fmt(a.ack_at) + " by officer " + a.officer_id : ""}
    ${me.role === "police" ? `<button data-ack="${a.id}">Acknowledge</button> <button data-mng="${a.id}" class="green">Mark Junction Managed</button>` : ""}</div>`).join("") || "No active alerts.";
  document.querySelectorAll("[data-ack]").forEach(b => b.onclick = () => act(() => api(`/alerts/${b.dataset.ack}/acknowledge`, "POST")));
  document.querySelectorAll("[data-mng]").forEach(b => b.onclick = () => act(() => api(`/alerts/${b.dataset.mng}/junction-status`, "POST", { status: "MANAGED" })));
}
async function act(fn) { if (busy) return; busy = true; try { await fn(); await refresh(); } catch (e) { note("Error: " + e.message); alert(e.message); } finally { busy = false; } }
function renderPanel() {
  const p = $("#panel"), live = trips.filter(t => ["ACTIVE", "PAUSED"].includes(t.status)), mine = live[0];
  if (me.role === "driver") {
    p.innerHTML = `<h3>Ambulance AMB-${me.ambulance_id} · ${esc(me.name)}</h3>` + (mine ? tripCard(mine) + `<button id="pause">${mine.status === "ACTIVE" ? "Pause" : "Resume"} Trip</button> <button id="rr">Reroute</button> <button id="done" class="green">Complete Trip</button> <button id="sim">${sim ? "Stop" : "Start"} DEMO movement</button> <button id="track">${watch !== null ? "Stop" : "Start"} GPS tracking</button>`
      : `<label>Origin (click map or use GPS)</label><input id="origin" placeholder="lat,lon"><button id="gps">Use my GPS</button><label>Hospital</label><select id="hosp">${hospitals.map(h => `<option value="${h.id}">${esc(h.name)}</option>`).join("")}</select><label>Category</label><select id="cat"><option>CRITICAL</option><option selected>URGENT</option><option>ROUTINE</option></select><br><br><button id="go" class="red">Start Trip</button> <div id="perr" class="err"></div>`);
    if ($("#go")) {
      if (origin) $("#origin").value = origin.lat.toFixed(5) + "," + origin.lng.toFixed(5);
      if (form.hosp) $("#hosp").value = form.hosp; $("#cat").value = form.cat;
      $("#hosp").onchange = e => form.hosp = e.target.value; $("#cat").onchange = e => form.cat = e.target.value;
      $("#go").onclick = startTrip; $("#gps").onclick = gps;
    }
    if (mine) { $("#pause").onclick = () => act(() => api(`/trips/${mine.id}/status`, "PATCH", { status: mine.status === "ACTIVE" ? "PAUSED" : "ACTIVE", expected_status: mine.status })); $("#done").onclick = () => { stopSim(); act(() => api(`/trips/${mine.id}/status`, "PATCH", { status: "COMPLETED" })); };
      $("#sim").onclick = () => sim ? (stopSim(), refresh()) : startSim(mine); $("#rr").onclick = () => act(async () => { const h = hospitals.find(x => x.id === mine.hospital_id), r = await getRoute(mine.cur_lat, mine.cur_lon, h);
        if (!r.route) throw new Error("No road route available; keeping the current route."); await api(`/trips/${mine.id}/route`, "PATCH", r); });
      $("#track").onclick = () => toggleTrack(mine); }
  } else if (me.role === "police") {
    p.innerHTML = `<h3>Active ambulances</h3>` + (live.map(t => tripCard(t, `<br><button data-view="${t.id}">View Route</button> <button data-cong="${t.id}">Report Congestion</button>`)).join("") || "None.") + `<h3>Junction acknowledgments</h3><small>Records coordination only; it does not change signals.</small>`;
    document.querySelectorAll("[data-view]").forEach(b => b.onclick = () => draw(b.dataset.view));
    document.querySelectorAll("[data-cong]").forEach(b => b.onclick = () => dialog(`<h3>Report congestion</h3><label>Junction</label><select name="j">${junctions.map(j => `<option value="${j.id}">${esc(j.name)}</option>`).join("")}</select><label>Note</label><input name="n" maxlength="300">`, f => act(() => api(`/trips/${b.dataset.cong}/alerts`, "POST", { type: "CONGESTION", junction_id: +f.get("j"), note: f.get("n") }))));
  } else {
    p.innerHTML = `<h3>${esc((hospitals.find(h => h.id === me.hospital_id) || { name: "All hospitals" }).name)} — incoming ambulances</h3>` + (live.map(t => tripCard(t, `<br><button data-hack="${t.id}">Arrival Acknowledgment</button> <button data-arr="${t.id}" class="green">Mark Ambulance Arrived</button>`)).join("") || "None.") + `<h3>History</h3>` + trips.filter(t => !["ACTIVE", "PAUSED"].includes(t.status)).slice(0, 5).map(t => tripCard(t)).join("");
    document.querySelectorAll("[data-hack]").forEach(b => b.onclick = () => act(() => api(`/trips/${b.dataset.hack}/hospital-ack`, "POST")));
    document.querySelectorAll("[data-arr]").forEach(b => b.onclick = () => act(() => api(`/trips/${b.dataset.arr}/arrived`, "POST")));
  }
}
async function getRoute(la, lo, h) { try { return (await api(`/route?o_lat=${la}&o_lon=${lo}&d_lat=${h.lat}&d_lon=${h.lon}`)); } catch (e) { if (!confirm("Routing failed (" + e.message + "). Use a SIMULATED straight-line route instead? Cancel to retry later.")) throw e; return {}; } }
function gps() { if (!navigator.geolocation) return alert("Geolocation unavailable. Use the map click or DEMO mode.");
  navigator.geolocation.getCurrentPosition(p => { origin = { lat: p.coords.latitude, lng: p.coords.longitude }; $("#origin") && ($("#origin").value = origin.lat.toFixed(5) + "," + origin.lng.toFixed(5)); },
    e => alert(e.code === 1 ? "Location permission denied. Click the map to set an origin." : e.code === 3 ? "Location request timed out." : "Location unavailable."), { timeout: 10000 }); }
async function startTrip() {
  if (busy) return; const v = ($("#origin").value || "").split(",").map(Number), hid = +$("#hosp").value;
  if (v.length !== 2 || v.some(isNaN) || Math.abs(v[0]) > 90 || Math.abs(v[1]) > 180) return $("#perr").textContent = "Select a valid origin first.";
  if (!hid) return $("#perr").textContent = "Select a hospital."; $("#perr").textContent = "";
  await act(async () => { const h = hospitals.find(x => x.id === hid), r = await getRoute(v[0], v[1], h);
    await api("/trips", "POST", { origin_lat: v[0], origin_lon: v[1], hospital_id: hid, ambulance_id: me.ambulance_id, category: $("#cat").value, route: r.route, distance_m: r.distance_m, duration_s: r.duration_s, route_source: r.route ? "osrm" : "simulated" }); });
}
function startSim(t) { const r = t.route; let i = Math.max(0, r.findIndex(p => p[0] === t.cur_lat && p[1] === t.cur_lon)); note("DEMO movement started (simulated GPS)");
  sim = setInterval(async () => { i = Math.min(i + Math.max(1, Math.floor(r.length / 40)), r.length - 1); try { await api(`/trips/${t.id}/location`, "PATCH", { lat: r[i][0], lon: r[i][1] }); } catch (e) { note("Location update failed: " + e.message); stopSim(); } if (i >= r.length - 1) stopSim(); }, 1500); renderPanel(); }
function stopSim() { clearInterval(sim); sim = null; }
function toggleTrack(t) {
  if (watch !== null) { navigator.geolocation.clearWatch(watch); watch = null; return renderPanel(); }
  if (!navigator.geolocation) return alert("Geolocation unavailable. Use DEMO movement.");
  stopSim();
  watch = navigator.geolocation.watchPosition(p => {
    if (Date.now() - lastSent < 3000) return; lastSent = Date.now();
    api(`/trips/${t.id}/location`, "PATCH", { lat: p.coords.latitude, lon: p.coords.longitude }).catch(e => note("Location update failed: " + e.message));
  }, e => { navigator.geolocation.clearWatch(watch); watch = null; alert(e.code === 1 ? "Location permission denied. Use DEMO movement." : "Location unavailable or timed out."); renderPanel(); }, { enableHighAccuracy: true, timeout: 15000 });
  renderPanel();
}
async function enter() {
  $("#dlg").open && $("#dlg").close(); $("#home").hidden = true; $("#dash").hidden = false; $("#logout").hidden = false; $("#who").textContent = me.name + " · " + me.role;
  $("#nav").innerHTML = `<button>${{ driver: "Ambulance", police: "Traffic Police", hospital: "Hospital", admin: "Admin" }[me.role]} dashboard</button>` + (me.role === "admin" ? '<button id="rst">Reset Demo</button>' : "");
  if ($("#rst")) $("#rst").onclick = () => confirm("Reset demo data only?") && act(() => api("/admin/reset-demo", "POST"));
  initMap(); setTimeout(() => map.invalidateSize(), 100);
  try { hospitals = (await api("/hospitals")).data; junctions = (await api("/junctions")).data; } catch (e) { return alert(e.message); }
  connect(); refresh();
}
if (token && me) enter(); else fetch("/api/health").catch(() => {});
