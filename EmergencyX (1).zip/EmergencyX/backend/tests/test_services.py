import os, tempfile, unittest
from backend.app import auth, services as S
from backend.app.db import get_db, init_db

def U(c, name): return dict(c.execute("SELECT * FROM users WHERE username=?", (name,)).fetchone())
TRIP = dict(origin_lat=51.4946, origin_lon=-0.1002, hospital_id=2, ambulance_id=1, category="CRITICAL")

class ServiceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ["EMX_DB"] = os.path.join(tempfile.mkdtemp(), "t.db"); init_db()
    def setUp(self):
        self.c = get_db(); self.c.execute("UPDATE trips SET status='CANCELLED' WHERE status IN ('ACTIVE','PAUSED')"); self.c.commit()
    def test_password_hash_and_token(self):
        h = auth.hash_password("x"); self.assertNotIn("x$", h[:5]); self.assertTrue(auth.verify_password("x", h)); self.assertFalse(auth.verify_password("y", h))
        t = auth.make_token(1, "driver"); self.assertEqual(auth.read_token(t)["uid"], 1); self.assertIsNone(auth.read_token(t + "x"))
        self.assertIsNone(auth.read_token(auth.make_token(1, "driver", ttl=-1)))
    def test_seed_persisted(self):
        self.assertGreaterEqual(self.c.execute("SELECT COUNT(*) FROM hospitals").fetchone()[0], 3)
        self.assertGreaterEqual(self.c.execute("SELECT COUNT(*) FROM junctions").fetchone()[0], 5)
        self.assertNotEqual(U(self.c, "driver1")["password_hash"], "driver123")
    def test_create_trip_and_alerts(self):
        t = S.create_trip(self.c, U(self.c, "driver1"), TRIP)
        self.assertEqual(t["status"], "ACTIVE"); self.assertEqual(t["route_source"], "simulated"); self.assertTrue(t["id"].startswith("T-"))
        self.assertGreater(len(S.alerts_for(self.c, U(self.c, "police1"), t["id"])), 0)
    def test_invalid_trip_and_duplicate(self):
        d = U(self.c, "driver1")
        for bad in (dict(TRIP, origin_lat=999), dict(TRIP, hospital_id=99), dict(TRIP, category="X")):
            with self.assertRaises(ValueError): S.create_trip(self.c, d, bad)
        with self.assertRaises(PermissionError): S.create_trip(self.c, d, dict(TRIP, ambulance_id=2))
        with self.assertRaises(PermissionError): S.create_trip(self.c, U(self.c, "police1"), TRIP)
        S.create_trip(self.c, d, TRIP)
        with self.assertRaises(S.Conflict): S.create_trip(self.c, d, TRIP)
    def test_location_status_transitions(self):
        d = U(self.c, "driver1"); t = S.create_trip(self.c, d, TRIP)
        r = S.update_location(self.c, d, t["id"], 51.5, -0.09); self.assertLess(r["remaining_m"], t["distance_m"]); self.assertTrue(r["eta"])
        with self.assertRaises(ValueError): S.update_location(self.c, d, t["id"], 100, 0)
        with self.assertRaises(PermissionError): S.update_location(self.c, U(self.c, "police1"), t["id"], 51.5, -0.09)
        S.set_status(self.c, d, t["id"], "PAUSED")
        with self.assertRaises(S.Conflict): S.update_location(self.c, d, t["id"], 51.5, -0.09)
        S.set_status(self.c, d, t["id"], "ACTIVE")
        with self.assertRaises(S.Conflict): S.set_status(self.c, d, t["id"], "ACTIVE")
        self.assertEqual(S.set_status(self.c, d, t["id"], "COMPLETED")["status"], "COMPLETED")
        with self.assertRaises(S.Conflict): S.set_status(self.c, d, t["id"], "ACTIVE")
    def test_alert_flow(self):
        d, p = U(self.c, "driver1"), U(self.c, "police1"); t = S.create_trip(self.c, d, TRIP)
        a = S.alerts_for(self.c, p, t["id"])[0]
        with self.assertRaises(PermissionError): S.set_alert_status(self.c, d, a["id"], "ACKNOWLEDGED")
        r = S.set_alert_status(self.c, p, a["id"], "ACKNOWLEDGED"); self.assertEqual((r["status"], r["officer_id"]), ("ACKNOWLEDGED", p["id"])); self.assertTrue(r["ack_at"])
        self.assertEqual(S.set_alert_status(self.c, p, a["id"], "MANAGED")["status"], "MANAGED")
        with self.assertRaises(ValueError): S.set_alert_status(self.c, p, a["id"], "BOGUS")
        c2 = S.create_alert(self.c, p, t["id"], "CONGESTION", 1, "sample"); self.assertEqual(c2["status"], "PENDING")
    def test_hospital_arrival_and_history(self):
        d, h = U(self.c, "driver1"), U(self.c, "hospital1"); t = S.create_trip(self.c, d, dict(TRIP, hospital_id=1))
        self.assertEqual(len(S.list_trips(self.c, h, True)), 1)
        S.hospital_ack(self.c, h, t["id"]); self.assertEqual(S.mark_arrived(self.c, h, t["id"])["status"], "ARRIVED")
        self.assertEqual(len(S.list_trips(self.c, h, True)), 0)
        self.assertIn("ARRIVED", [e["type"] for e in S.history(self.c, h, t["id"])["events"]])
        self.assertEqual(S.history(self.c, h, t["id"])["locations"], [])
    def test_hospital_cannot_see_other_hospital_trip(self):
        t = S.create_trip(self.c, U(self.c, "driver1"), TRIP)  # hospital 2; hospital1 staff belong to hospital 1
        with self.assertRaises(PermissionError): S.authorized_trip(self.c, U(self.c, "hospital1"), t["id"])
    def test_summary_and_reset_demo(self):
        s = S.summary(self.c); self.assertTrue(s["includes_demo_data"]); self.assertGreaterEqual(s["completed_trips"], 2); self.assertIsNotNone(s["avg_ack_s"])
        S.reset_demo(self.c); self.assertEqual(self.c.execute("SELECT COUNT(*) FROM trips WHERE is_demo=1").fetchone()[0], 2)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM users").fetchone()[0], 5)
if __name__ == "__main__": unittest.main()
