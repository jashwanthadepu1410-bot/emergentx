import os, tempfile, pytest
pytest.importorskip("fastapi"); pytest.importorskip("httpx")
from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect
from backend.app.main import app

TRIP = dict(origin_lat=51.4946, origin_lon=-0.1002, hospital_id=1, ambulance_id=1, category="URGENT")
@pytest.fixture(scope="module")
def client(tmp_path_factory):
    os.environ["EMX_DB"] = str(tmp_path_factory.mktemp("api") / "api.db")
    with TestClient(app) as c: yield c
def hdr(c, u, p): return {"Authorization": "Bearer " + c.post("/api/auth/login", json={"username": u, "password": p}).json()["token"]}

def test_health(client): assert client.get("/api/health").json()["status"] == "up"
def test_login(client):
    assert client.post("/api/auth/login", json={"username": "driver1", "password": "bad"}).status_code == 401
    assert client.get("/api/trips").status_code == 401
def test_login_rate_limit(client):
    codes = [client.post("/api/auth/login", json={"username": "nobody", "password": "x"}).status_code for _ in range(6)]
    assert codes[:5] == [401] * 5 and codes[5] == 429
def test_full_flow_and_ws(client):
    d, p, h = hdr(client, "driver1", "driver123"), hdr(client, "police1", "police123"), hdr(client, "hospital1", "hospital123")
    assert client.post("/api/trips", json=dict(TRIP, hospital_id=99), headers=d).status_code == 422
    assert client.post("/api/trips", json=TRIP, headers=p).status_code == 403
    tok = d["Authorization"][7:]
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ws/trips/all?token=bad"): pass
    with client.websocket_connect(f"/ws/trips/all?token={tok}") as ws:
        t = client.post("/api/trips", json=TRIP, headers=d); assert t.status_code == 201; tid = t.json()["data"]["id"]
        assert ws.receive_json()["type"] == "trip_started"
        assert client.post("/api/trips", json=TRIP, headers=d).status_code == 409
        r = client.patch(f"/api/trips/{tid}/location", json={"lat": 51.5, "lon": -0.09}, headers=d); assert r.status_code == 200
        assert ws.receive_json()["type"] == "location"
    assert client.patch(f"/api/trips/{tid}/location", json={"lat": 51.5, "lon": -0.09}, headers=p).status_code == 403
    aid = client.get(f"/api/trips/{tid}/alerts", headers=p).json()["data"][0]["id"]
    assert client.post(f"/api/alerts/{aid}/acknowledge", headers=d).status_code == 403
    assert client.post(f"/api/alerts/{aid}/acknowledge", headers=p).json()["data"]["status"] == "ACKNOWLEDGED"
    assert client.post(f"/api/alerts/{aid}/junction-status", json={"status": "MANAGED"}, headers=p).status_code == 200
    assert client.get(f"/api/trips/{tid}", headers=h).status_code == 200
    assert client.post(f"/api/trips/{tid}/arrived", headers=h).json()["data"]["status"] == "ARRIVED"
    assert len(client.get(f"/api/trips/{tid}/history", headers=p).json()["data"]["events"]) >= 3
    assert client.get("/api/analytics/summary", headers=p).json()["data"]["completed_trips"] >= 3
