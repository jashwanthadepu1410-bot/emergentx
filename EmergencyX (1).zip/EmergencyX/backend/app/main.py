import json, logging, os, time, urllib.request
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Optional
from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from . import auth, services as S
from .db import get_db, init_db

log = logging.getLogger("emx")
ROOT = Path(__file__).resolve().parents[2]
@asynccontextmanager
async def lifespan(_):
    init_db()
    yield

app = FastAPI(title="Emergency X", version="1.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=os.environ.get("EMX_ORIGINS", "http://127.0.0.1:8000,http://localhost:8000").split(","),
                   allow_methods=["*"], allow_headers=["*"])

@app.exception_handler(ValueError)
async def _v(_, e): return JSONResponse({"ok": False, "error": str(e)}, 422)
@app.exception_handler(PermissionError)
async def _p(_, e): return JSONResponse({"ok": False, "error": str(e)}, 403)
@app.exception_handler(LookupError)
async def _l(_, e): return JSONResponse({"ok": False, "error": str(e)}, 404)
@app.exception_handler(S.Conflict)
async def _c(_, e): return JSONResponse({"ok": False, "error": str(e)}, 409)

def db():
    c = get_db()
    try: yield c
    finally: c.close()
def user_from_token(c, tok):
    d = auth.read_token(tok or "")
    r = c.execute("SELECT * FROM users WHERE id=?", (d["uid"],)).fetchone() if d else None
    return dict(r) if r else None
def current_user(authorization: Optional[str] = Header(None), c=Depends(db)):
    u = user_from_token(c, (authorization or "").removeprefix("Bearer "))
    if not u: raise HTTPException(401, "authentication required")
    return u
def require(*roles):
    def dep(u=Depends(current_user)):
        if u["role"] not in roles: raise HTTPException(403, "role not permitted")
        return u
    return dep

class Hub:
    """Tracks WebSocket clients as (socket, user, subscription) where subscription is a trip id or "all"."""
    def __init__(self): self.conns = []
    def remove(self, ws): self.conns[:] = [x for x in self.conns if x[0] is not ws]
    async def broadcast(self, c, tid, msg):
        trip = S.get_trip(c, tid)
        for ws, user, sub in list(self.conns):
            if sub not in ("all", tid) or not S.can_view(c, user, trip): continue
            try: await ws.send_json(msg)
            except Exception: self.remove(ws)

hub = Hub()

class Login(BaseModel): username: str = Field(min_length=1, max_length=64); password: str = Field(min_length=1, max_length=128)
class TripIn(BaseModel):
    origin_lat: float = Field(ge=-90, le=90); origin_lon: float = Field(ge=-180, le=180); hospital_id: int
    ambulance_id: Optional[int] = None; category: str = "URGENT"
    route: Optional[List[List[float]]] = None; distance_m: Optional[float] = None; duration_s: Optional[float] = None
    route_source: str = "osrm"
class Loc(BaseModel): lat: float = Field(ge=-90, le=90); lon: float = Field(ge=-180, le=180)
class Status(BaseModel): status: str; expected_status: Optional[str] = None
class RouteIn(BaseModel): route: List[List[float]]; distance_m: float; duration_s: float; route_source: str = "osrm"
class AlertIn(BaseModel): type: str; junction_id: Optional[int] = None; note: Optional[str] = Field(None, max_length=300)
class AlertStatus(BaseModel): status: str
class DemoReq(BaseModel): name: str = Field(min_length=1, max_length=80); email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$"); organisation: str = Field("", max_length=120)
ok = lambda **k: {"ok": True, **k}

@app.get("/api/health")
def health(): return ok(status="up")
FAILED_LOGINS = {}
def throttle(key, limit=5, window=60):
    recent = [t for t in FAILED_LOGINS.get(key, []) if time.time() - t < window]
    FAILED_LOGINS[key] = recent
    if len(recent) >= limit: raise HTTPException(429, "too many failed logins; wait a minute")
@app.post("/api/auth/login")
def login(b: Login, request: Request, c=Depends(db)):
    key = (request.client.host if request.client else "?", b.username)
    throttle(key)
    r = c.execute("SELECT * FROM users WHERE username=?", (b.username,)).fetchone()
    if not r or not auth.verify_password(b.password, r["password_hash"]):
        FAILED_LOGINS[key].append(time.time()); raise HTTPException(401, "invalid username or password")
    return ok(token=auth.make_token(r["id"], r["role"]), user={k: r[k] for k in ("id", "username", "role", "name", "hospital_id", "ambulance_id")})
@app.post("/api/demo-requests", status_code=201)
def demo_request(b: DemoReq, c=Depends(db)):
    c.execute("INSERT INTO demo_requests(name,email,organisation,at) VALUES(?,?,?,?)", (b.name, b.email, b.organisation, S.now())); c.commit(); return ok()
@app.get("/api/ambulances")
def ambulances(u=Depends(current_user), c=Depends(db)): return ok(data=[dict(r) for r in c.execute("SELECT * FROM ambulances")])
@app.get("/api/hospitals")
def hospitals(u=Depends(current_user), c=Depends(db)): return ok(data=[dict(r) for r in c.execute("SELECT * FROM hospitals")])
@app.get("/api/junctions")
def junctions(u=Depends(current_user), c=Depends(db)): return ok(data=[dict(r) for r in c.execute("SELECT * FROM junctions")])
@app.get("/api/route")
def route(o_lat: float, o_lon: float, d_lat: float, d_lon: float, u=Depends(current_user)):
    """Proxy to OSRM (configurable). Never fabricates geometry: returns 502 on failure."""
    base = os.environ.get("OSRM_URL", "https://router.project-osrm.org")
    try:
        with urllib.request.urlopen(f"{base}/route/v1/driving/{o_lon},{o_lat};{d_lon},{d_lat}?overview=full&geometries=geojson", timeout=8) as r: j = json.load(r)
        rt = j["routes"][0]
        return ok(route=[[y, x] for x, y in rt["geometry"]["coordinates"]], distance_m=rt["distance"], duration_s=rt["duration"], route_source="osrm")
    except Exception as e:
        log.warning("routing failed: %s", type(e).__name__)
        raise HTTPException(502, "routing provider unavailable")
@app.get("/api/trips")
def trips(active: bool = False, u=Depends(current_user), c=Depends(db)): return ok(data=S.list_trips(c, u, active))
@app.get("/api/trips/{tid}")
def trip(tid: str, u=Depends(current_user), c=Depends(db)): return ok(data=S.trip_dict(S.authorized_trip(c, u, tid)))
@app.post("/api/trips", status_code=201)
async def new_trip(b: TripIn, u=Depends(current_user), c=Depends(db)):
    t = S.create_trip(c, u, b.model_dump()); await hub.broadcast(c, t["id"], {"type": "trip_started", "trip": t}); return ok(data=t)
@app.patch("/api/trips/{tid}/location")
async def location(tid: str, b: Loc, u=Depends(current_user), c=Depends(db)):
    t = S.update_location(c, u, tid, b.lat, b.lon); await hub.broadcast(c, tid, {"type": "location", "trip": t}); return ok(data=t)
@app.patch("/api/trips/{tid}/route")
async def reroute(tid: str, b: RouteIn, u=Depends(current_user), c=Depends(db)):
    t = S.set_route(c, u, tid, b.route, b.distance_m, b.duration_s, b.route_source); await hub.broadcast(c, tid, {"type": "route", "trip": t}); return ok(data=t)
@app.patch("/api/trips/{tid}/status")
async def status(tid: str, b: Status, u=Depends(current_user), c=Depends(db)):
    t = S.set_status(c, u, tid, b.status, b.expected_status); await hub.broadcast(c, tid, {"type": "status", "trip": t}); return ok(data=t)
@app.post("/api/trips/{tid}/arrived")
async def arrived(tid: str, u=Depends(current_user), c=Depends(db)):
    t = S.mark_arrived(c, u, tid); await hub.broadcast(c, tid, {"type": "arrived", "trip": t}); return ok(data=t)
@app.post("/api/trips/{tid}/hospital-ack")
async def hack(tid: str, u=Depends(current_user), c=Depends(db)):
    t = S.hospital_ack(c, u, tid); await hub.broadcast(c, tid, {"type": "hospital_ack", "trip": t}); return ok(data=t)
@app.get("/api/trips/{tid}/alerts")
def trip_alerts(tid: str, u=Depends(current_user), c=Depends(db)): S.authorized_trip(c, u, tid); return ok(data=S.alerts_for(c, u, tid))
@app.get("/api/alerts")
def all_alerts(u=Depends(current_user), c=Depends(db)): return ok(data=S.alerts_for(c, u))
@app.post("/api/trips/{tid}/alerts", status_code=201)
async def mk_alert(tid: str, b: AlertIn, u=Depends(current_user), c=Depends(db)):
    a = S.create_alert(c, u, tid, b.type, b.junction_id, b.note); await hub.broadcast(c, tid, {"type": "alert", "alert": a}); return ok(data=a)
@app.post("/api/alerts/{aid}/acknowledge")
async def ack(aid: int, u=Depends(current_user), c=Depends(db)):
    a = S.set_alert_status(c, u, aid, "ACKNOWLEDGED"); await hub.broadcast(c, a["trip_id"], {"type": "alert_ack", "alert": a}); return ok(data=a)
@app.post("/api/alerts/{aid}/junction-status")
async def jstatus(aid: int, b: AlertStatus, u=Depends(current_user), c=Depends(db)):
    a = S.set_alert_status(c, u, aid, b.status); await hub.broadcast(c, a["trip_id"], {"type": "junction_status", "alert": a}); return ok(data=a)
@app.get("/api/trips/{tid}/history")
def hist(tid: str, u=Depends(current_user), c=Depends(db)): return ok(data=S.history(c, u, tid))
@app.get("/api/analytics/summary")
def analytics(u=Depends(current_user), c=Depends(db)): return ok(data=S.summary(c))
@app.post("/api/admin/reset-demo")
def reset(u=Depends(require("admin")), c=Depends(db)): S.reset_demo(c); return ok()

@app.websocket("/ws/trips/{tid}")
async def ws_trips(ws: WebSocket, tid: str, token: str = Query("")):
    c = get_db()
    try:
        u = user_from_token(c, token)
        if not u: await ws.close(code=4401); return
        if tid != "all":
            try: S.authorized_trip(c, u, tid)
            except (LookupError, PermissionError): await ws.close(code=4403); return
        await ws.accept(); hub.conns.append((ws, u, tid))
        try:
            while True: await ws.receive_text()
        except WebSocketDisconnect: pass
        finally: hub.remove(ws)
    finally: c.close()

@app.get("/")
def index(): return FileResponse(ROOT / "index.html")
app.mount("/assets", StaticFiles(directory=ROOT / "assets"), name="assets")
