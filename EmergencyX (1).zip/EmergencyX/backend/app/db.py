import os, sqlite3
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL, name TEXT, hospital_id INTEGER, ambulance_id INTEGER);
CREATE TABLE IF NOT EXISTS ambulances(id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, driver_id INTEGER);
CREATE TABLE IF NOT EXISTS hospitals(id INTEGER PRIMARY KEY, name TEXT NOT NULL, lat REAL NOT NULL, lon REAL NOT NULL);
CREATE TABLE IF NOT EXISTS junctions(id INTEGER PRIMARY KEY, name TEXT NOT NULL, lat REAL NOT NULL, lon REAL NOT NULL);
CREATE TABLE IF NOT EXISTS trips(id TEXT PRIMARY KEY, ambulance_id INTEGER NOT NULL, driver_id INTEGER, origin_lat REAL, origin_lon REAL,
 hospital_id INTEGER NOT NULL, cur_lat REAL, cur_lon REAL, started_at TEXT, last_loc_at TEXT, distance_m REAL, duration_s REAL, remaining_m REAL,
 eta TEXT, status TEXT NOT NULL, completed_at TEXT, category TEXT, case_ref TEXT, route_json TEXT, route_source TEXT, is_demo INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS trip_locations(id INTEGER PRIMARY KEY, trip_id TEXT, lat REAL, lon REAL, at TEXT);
CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY, trip_id TEXT, junction_id INTEGER, type TEXT, created_at TEXT, ack_at TEXT, status TEXT,
 officer_id INTEGER, priority REAL, note TEXT, is_demo INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS alert_acks(id INTEGER PRIMARY KEY, alert_id INTEGER, officer_id INTEGER, status TEXT, at TEXT);
CREATE TABLE IF NOT EXISTS trip_events(id INTEGER PRIMARY KEY, trip_id TEXT, type TEXT, message TEXT, role TEXT, at TEXT);
CREATE TABLE IF NOT EXISTS demo_requests(id INTEGER PRIMARY KEY, name TEXT, email TEXT, organisation TEXT, at TEXT);
"""
def get_db():
    c = sqlite3.connect(os.environ.get("EMX_DB", "emergencyx.db"), timeout=10, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c
def init_db():
    c = get_db(); c.executescript(SCHEMA); c.commit()
    if not c.execute("SELECT 1 FROM users").fetchone():
        from .seed import seed; seed(c)
    c.close()
