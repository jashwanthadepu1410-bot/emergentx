import base64, hashlib, hmac, json, os, secrets, time
SECRET = (os.environ.get("EMX_SECRET") or secrets.token_hex(32)).encode()
ROLES = {"driver", "police", "hospital", "admin"}
def hash_password(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()
    return f"pbkdf2${salt}${h}"
def verify_password(pw, stored):
    try: _, salt, h = stored.split("$")
    except ValueError: return False
    return hmac.compare_digest(hash_password(pw, salt), stored)
def make_token(uid, role, ttl=8 * 3600):
    body = base64.urlsafe_b64encode(json.dumps({"uid": uid, "role": role, "exp": time.time() + ttl}).encode()).decode()
    return body + "." + hmac.new(SECRET, body.encode(), hashlib.sha256).hexdigest()
def read_token(tok):
    try:
        body, sig = tok.split(".")
        if not hmac.compare_digest(sig, hmac.new(SECRET, body.encode(), hashlib.sha256).hexdigest()): return None
        d = json.loads(base64.urlsafe_b64decode(body))
        return d if d["exp"] > time.time() else None
    except Exception: return None
