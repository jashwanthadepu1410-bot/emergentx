import json
from .auth import hash_password
from .services import now, hav
HOSPITALS = [("St Thomas' Hospital (DEMO)", 51.4988, -0.1187), ("Royal London Hospital (DEMO)", 51.5186, -0.0589), ("UCLH (DEMO)", 51.5246, -0.1340)]
JUNCTIONS = [("Westminster Bridge", 51.5008, -0.1219), ("Elephant & Castle", 51.4946, -0.1002), ("Bank", 51.5134, -0.0890),
             ("Tottenham Court Rd", 51.5165, -0.1310), ("Aldgate", 51.5145, -0.0755), ("Euston Rd / Gower St", 51.5256, -0.1350)]
USERS = [("driver1", "driver123", "driver", "Demo Driver 1", None, 1), ("driver2", "driver123", "driver", "Demo Driver 2", None, 2),
         ("police1", "police123", "police", "Officer Demo", None, None), ("hospital1", "hospital123", "hospital", "Staff Demo", 1, None),
         ("admin", "admin123", "admin", "Administrator", None, None)]
def seed(c, demo_only=False):
    if not demo_only:
        for i, (n, la, lo) in enumerate(HOSPITALS, 1): c.execute("INSERT INTO hospitals VALUES(?,?,?,?)", (i, n, la, lo))
        for i, (n, la, lo) in enumerate(JUNCTIONS, 1): c.execute("INSERT INTO junctions VALUES(?,?,?,?)", (i, n, la, lo))
        for i, (u, p, r, n, h, a) in enumerate(USERS, 1): c.execute("INSERT INTO users VALUES(?,?,?,?,?,?,?)", (i, u, hash_password(p), r, n, h, a))
        c.execute("INSERT INTO ambulances VALUES(1,'AMB-101',1)"); c.execute("INSERT INTO ambulances VALUES(2,'AMB-102',2)")
    # sample history: two completed demo trips (is_demo=1, simulated routes)
    for k, (amb, hosp, dur, plan) in enumerate([(1, 1, 600, 540), (2, 3, 900, 840)], 1):
        h = HOSPITALS[hosp - 1]
        c.execute("INSERT INTO trips(id,ambulance_id,driver_id,origin_lat,origin_lon,hospital_id,cur_lat,cur_lon,started_at,last_loc_at,distance_m,duration_s,remaining_m,status,completed_at,category,case_ref,route_source,is_demo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
                  (f"DEMO-HIST-{k}", amb, amb, 51.5, -0.1, hosp, h[1], h[2], "2026-01-01T10:00:00+00:00", "2026-01-01T10:10:00+00:00", 4000, plan, 0, "ARRIVED",
                   f"2026-01-01T10:{dur // 60:02d}:00+00:00", "URGENT", f"CASE-DEMO-{k}", "simulated"))
        c.execute("INSERT INTO alerts(trip_id,junction_id,type,created_at,ack_at,status,officer_id,priority,is_demo) VALUES(?,?,?,?,?,?,?,?,1)",
                  (f"DEMO-HIST-{k}", k, "JUNCTION_CLEARANCE", "2026-01-01T10:01:00+00:00", "2026-01-01T10:01:40+00:00", "MANAGED", 3, 0.7))
    c.commit()
