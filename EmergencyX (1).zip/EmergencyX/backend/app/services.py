import datetime as dt, json, math, uuid
class Conflict(Exception): pass
TRANSITIONS = {"ACTIVE": {"PAUSED", "COMPLETED", "CANCELLED"}, "PAUSED": {"ACTIVE", "CANCELLED", "COMPLETED"}}
TERMINAL = ("COMPLETED", "ARRIVED", "CANCELLED")
URGENCY = {"CRITICAL": 1.0, "URGENT": 0.7, "ROUTINE": 0.4}
def now(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
def hav(a, b, c, d):
    p1, p2 = math.radians(a), math.radians(c)
    h = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(math.radians(d - b) / 2) ** 2
    return 2 * 6371000 * math.asin(math.sqrt(h))
def valid_coord(la, lo): return isinstance(la, (int, float)) and isinstance(lo, (int, float)) and -90 <= la <= 90 and -180 <= lo <= 180
def remaining(route, lat, lon, hosp):
    if not route: return hav(lat, lon, hosp["lat"], hosp["lon"])  # straight-line: approximation
    i = min(range(len(route)), key=lambda k: hav(lat, lon, route[k][0], route[k][1]))
    return hav(lat, lon, *route[i]) + sum(hav(*route[k], *route[k + 1]) for k in range(i, len(route) - 1))
def eta_for(trip, rem):
    speed = max((trip["distance_m"] or 1) / max(trip["duration_s"] or 1, 1), 1.0)
    return (dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=rem / speed)).isoformat(timespec="seconds")
def event(c, trip_id, typ, msg, role=None):
    c.execute("INSERT INTO trip_events(trip_id,type,message,role,at) VALUES(?,?,?,?,?)", (trip_id, typ, msg, role, now()))
def trip_dict(r, with_route=True):
    d = dict(r); route = json.loads(d.pop("route_json") or "null")
    if with_route: d["route"] = route
    return d
def get_trip(c, tid):
    r = c.execute("SELECT * FROM trips WHERE id=?", (tid,)).fetchone()
    if not r: raise LookupError("trip not found")
    return r
def can_view(c, user, trip):
    if user["role"] in ("admin", "police"): return True
    if user["role"] == "driver": return trip["ambulance_id"] == user["ambulance_id"]
    return user["role"] == "hospital" and trip["hospital_id"] == user["hospital_id"]
def authorized_trip(c, user, tid):
    t = get_trip(c, tid)
    if not can_view(c, user, t): raise PermissionError("not allowed for this trip")
    return t
def list_trips(c, user, active_only=False):
    rows = [r for r in c.execute("SELECT * FROM trips ORDER BY started_at DESC") if can_view(c, user, r)]
    if active_only: rows = [r for r in rows if r["status"] in ("ACTIVE", "PAUSED")]
    return [trip_dict(r) for r in rows]
def create_trip(c, user, d):
    if user["role"] not in ("driver", "admin"): raise PermissionError("only drivers can start trips")
    amb = d.get("ambulance_id") or user.get("ambulance_id")
    if user["role"] == "driver" and amb != user["ambulance_id"]: raise PermissionError("not your ambulance")
    if not valid_coord(d.get("origin_lat"), d.get("origin_lon")): raise ValueError("invalid origin coordinates")
    h = c.execute("SELECT * FROM hospitals WHERE id=?", (d.get("hospital_id"),)).fetchone()
    if not h: raise ValueError("unknown hospital")
    if not c.execute("SELECT 1 FROM ambulances WHERE id=?", (amb,)).fetchone(): raise ValueError("unknown ambulance")
    if c.execute("SELECT 1 FROM trips WHERE ambulance_id=? AND status IN ('ACTIVE','PAUSED')", (amb,)).fetchone():
        raise Conflict("ambulance already has an active trip")
    cat = d.get("category", "URGENT")
    if cat not in URGENCY: raise ValueError("invalid category")
    route = d.get("route") or []
    if route and not all(len(p) == 2 and valid_coord(*p) for p in route): raise ValueError("invalid route geometry")
    src = d.get("route_source", "osrm") if route else "simulated"
    if not route:  # clearly labelled straight line, NOT a road route
        route = [[d["origin_lat"] + (h["lat"] - d["origin_lat"]) * i / 40, d["origin_lon"] + (h["lon"] - d["origin_lon"]) * i / 40] for i in range(41)]
        dist = hav(d["origin_lat"], d["origin_lon"], h["lat"], h["lon"]); dur = dist / 11.1
    else:
        dist, dur = d.get("distance_m"), d.get("duration_s")
        if not dist or not dur or dist <= 0 or dur <= 0: raise ValueError("distance_m and duration_s required with route")
    tid = "T-" + uuid.uuid4().hex[:8].upper()
    t = now()
    c.execute("INSERT INTO trips VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)", (tid, amb, user["id"], d["origin_lat"], d["origin_lon"], h["id"], d["origin_lat"],
              d["origin_lon"], t, t, dist, dur, dist, None, "ACTIVE", None, cat, "CASE-" + uuid.uuid4().hex[:6].upper(), json.dumps(route), src))
    c.execute("UPDATE trips SET eta=? WHERE id=?", (eta_for({"distance_m": dist, "duration_s": dur}, dist), tid))
    event(c, tid, "TRIP_STARTED", f"Emergency trip {tid} started to {h['name']}", "driver")
    scored = []
    for j in c.execute("SELECT * FROM junctions"):
        near = min((hav(j["lat"], j["lon"], *p), i) for i, p in enumerate(route))
        if near[0] <= 300: scored.append((near[1], near[0], j))
    for idx, _, j in sorted(scored, key=lambda x: x[0]):
        pr = round(URGENCY[cat] / (1 + hav(d["origin_lat"], d["origin_lon"], j["lat"], j["lon"]) / 1000), 3)
        c.execute("INSERT INTO alerts(trip_id,junction_id,type,created_at,status,priority) VALUES(?,?,?,?,?,?)", (tid, j["id"], "JUNCTION_CLEARANCE", t, "PENDING", pr))
        event(c, tid, "ALERT", f"Coordination alert for {j['name']}", "police")
    c.commit()
    return trip_dict(get_trip(c, tid))
def update_location(c, user, tid, lat, lon):
    t = authorized_trip(c, user, tid)
    if user["role"] not in ("driver", "admin"): raise PermissionError("only the driver can update location")
    if not valid_coord(lat, lon): raise ValueError("invalid coordinates")
    if t["status"] != "ACTIVE": raise Conflict(f"trip is {t['status']}")
    h = c.execute("SELECT * FROM hospitals WHERE id=?", (t["hospital_id"],)).fetchone()
    rem = remaining(json.loads(t["route_json"] or "null"), lat, lon, h)
    c.execute("UPDATE trips SET cur_lat=?,cur_lon=?,last_loc_at=?,remaining_m=?,eta=? WHERE id=?", (lat, lon, now(), rem, eta_for(t, rem), tid))
    c.execute("INSERT INTO trip_locations(trip_id,lat,lon,at) VALUES(?,?,?,?)", (tid, lat, lon, now()))
    c.commit(); return trip_dict(get_trip(c, tid))
def set_route(c, user, tid, route, dist, dur, src):
    t = authorized_trip(c, user, tid)
    if user["role"] not in ("driver", "admin"): raise PermissionError("only the driver can reroute")
    if t["status"] not in ("ACTIVE", "PAUSED"): raise Conflict("trip is finished")
    if not route or not dist or not dur or dist <= 0 or dur <= 0: raise ValueError("invalid route")
    c.execute("UPDATE trips SET route_json=?,distance_m=?,duration_s=?,remaining_m=?,route_source=? WHERE id=?", (json.dumps(route), dist, dur, dist, src, tid))
    event(c, tid, "ROUTE_CHANGED", "Route changed by driver", "driver"); c.commit(); return trip_dict(get_trip(c, tid))
def set_status(c, user, tid, new, expected=None):
    t = authorized_trip(c, user, tid)
    if user["role"] not in ("driver", "admin"): raise PermissionError("only the driver can change trip status")
    if expected and expected != t["status"]: raise Conflict(f"expected {expected} but trip is {t['status']}")
    if new not in TRANSITIONS.get(t["status"], set()): raise Conflict(f"cannot go from {t['status']} to {new}")
    c.execute("UPDATE trips SET status=?,completed_at=? WHERE id=?", (new, now() if new in TERMINAL else None, tid))
    event(c, tid, "STATUS", f"Trip {new}", "driver"); c.commit(); return trip_dict(get_trip(c, tid))
def mark_arrived(c, user, tid):
    t = authorized_trip(c, user, tid)
    if user["role"] not in ("hospital", "driver", "admin"): raise PermissionError("not allowed")
    if t["status"] not in ("ACTIVE", "PAUSED"): raise Conflict(f"trip is {t['status']}")
    c.execute("UPDATE trips SET status='ARRIVED',completed_at=?,remaining_m=0 WHERE id=?", (now(), tid))
    event(c, tid, "ARRIVED", "Ambulance arrived at hospital", user["role"]); c.commit(); return trip_dict(get_trip(c, tid))
def hospital_ack(c, user, tid):
    t = authorized_trip(c, user, tid)
    if user["role"] not in ("hospital", "admin"): raise PermissionError("hospital staff only")
    event(c, tid, "HOSPITAL_ACK", "Hospital acknowledged incoming ambulance", "hospital"); c.commit(); return trip_dict(t)
def create_alert(c, user, tid, typ, junction_id=None, note=None):
    authorized_trip(c, user, tid)
    if user["role"] not in ("police", "admin"): raise PermissionError("police only")
    if typ not in ("CONGESTION", "INCIDENT", "JUNCTION_CLEARANCE"): raise ValueError("invalid alert type")
    if junction_id is not None and not c.execute("SELECT 1 FROM junctions WHERE id=?", (junction_id,)).fetchone(): raise ValueError("unknown junction")
    cur = c.execute("INSERT INTO alerts(trip_id,junction_id,type,created_at,status,priority,note) VALUES(?,?,?,?,?,?,?)", (tid, junction_id, typ, now(), "PENDING", 0.5, note))
    event(c, tid, "ALERT", f"{typ} reported", "police"); c.commit()
    return dict(c.execute("SELECT * FROM alerts WHERE id=?", (cur.lastrowid,)).fetchone())
def _alert(c, aid):
    a = c.execute("SELECT * FROM alerts WHERE id=?", (aid,)).fetchone()
    if not a: raise LookupError("alert not found")
    return a
def set_alert_status(c, user, aid, status):
    if user["role"] not in ("police", "admin"): raise PermissionError("police only")
    if status not in ("ACKNOWLEDGED", "MANAGED", "PENDING"): raise ValueError("invalid status")
    a = _alert(c, aid)
    if status == "ACKNOWLEDGED" and a["status"] == "MANAGED": raise Conflict("already managed")
    c.execute("UPDATE alerts SET status=?,officer_id=?,ack_at=COALESCE(ack_at,?) WHERE id=?", (status, user["id"], now() if status != "PENDING" else None, aid))
    c.execute("INSERT INTO alert_acks(alert_id,officer_id,status,at) VALUES(?,?,?,?)", (aid, user["id"], status, now()))
    event(c, a["trip_id"], "ALERT_" + status, f"Alert {aid} {status} by officer {user['id']}", "police"); c.commit()
    return dict(_alert(c, aid))
def alerts_for(c, user, tid=None):
    visible = {r["id"] for r in c.execute("SELECT * FROM trips") if can_view(c, user, r)}
    return [dict(a) for a in c.execute("SELECT * FROM alerts ORDER BY priority DESC, id") if a["trip_id"] in visible and tid in (None, a["trip_id"])]
def history(c, user, tid):
    authorized_trip(c, user, tid)
    return {"events": [dict(r) for r in c.execute("SELECT * FROM trip_events WHERE trip_id=? ORDER BY id", (tid,))],
            "locations": [dict(r) for r in c.execute("SELECT * FROM trip_locations WHERE trip_id=? ORDER BY id", (tid,))] if user["role"] in ("admin", "police", "driver") else []}
def summary(c):
    q = lambda s: c.execute(s).fetchone()[0]
    acks = [(dt.datetime.fromisoformat(r["ack_at"]) - dt.datetime.fromisoformat(r["created_at"])).total_seconds() for r in c.execute("SELECT * FROM alerts WHERE ack_at IS NOT NULL")]
    done = c.execute("SELECT * FROM trips WHERE completed_at IS NOT NULL").fetchall()
    dur = [(dt.datetime.fromisoformat(r["completed_at"]) - dt.datetime.fromisoformat(r["started_at"])).total_seconds() for r in done]
    delays = [max(0, d - r["duration_s"]) for d, r in zip(dur, done)]
    return {"active_trips": q("SELECT COUNT(*) FROM trips WHERE status IN ('ACTIVE','PAUSED')"), "tracked_ambulances": q("SELECT COUNT(DISTINCT ambulance_id) FROM trips WHERE status='ACTIVE'"),
            "incoming_arrivals": q("SELECT COUNT(*) FROM trips WHERE status IN ('ACTIVE','PAUSED')"), "pending_alerts": q("SELECT COUNT(*) FROM alerts a JOIN trips t ON t.id=a.trip_id WHERE a.status='PENDING' AND t.status IN ('ACTIVE','PAUSED')"),
            "completed_trips": len(done), "avg_journey_s": sum(dur) / len(dur) if dur else None, "avg_ack_s": sum(acks) / len(acks) if acks else None,
            "total_delay_s": sum(delays), "includes_demo_data": bool(q("SELECT COUNT(*) FROM trips WHERE is_demo=1") or q("SELECT COUNT(*) FROM alerts WHERE is_demo=1"))}
def reset_demo(c):
    from .seed import seed
    ids = [r[0] for r in c.execute("SELECT id FROM trips WHERE is_demo=1")]
    for t in ids:
        for tbl in ("trip_events", "trip_locations"): c.execute(f"DELETE FROM {tbl} WHERE trip_id=?", (t,))
    c.execute("DELETE FROM alerts WHERE is_demo=1"); c.execute("DELETE FROM trips WHERE is_demo=1"); seed(c, demo_only=True)
