@echo off
cd /d "%~dp0"
if not exist .venv (py -3 -m venv .venv || (echo Install Python 3.10+ from python.org & exit /b 1))
call .venv\Scripts\activate.bat
pip install -q -r requirements.txt || (echo pip install failed & exit /b 1)
if not defined EMX_SECRET set EMX_SECRET=%RANDOM%%RANDOM%%RANDOM%%RANDOM%-local-dev-only
echo Open http://127.0.0.1:8000  (Ctrl+C to stop)
uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
