# Emergency X — coordination prototype
Coordinates ambulance trips between drivers, traffic police and hospitals. **It does not control traffic signals or guarantee a green corridor.**

## Run (Windows)
1. Install Python 3.10+ from python.org (tick "Add to PATH").
2. Double-click `run_backend.bat` (creates `.venv`, installs requirements, starts FastAPI). Optionally copy `.env.example` to `.env` values into your environment first; set `EMX_SECRET` for anything beyond local use (the batch file generates a random one per start, so you must sign in again after a restart).
3. Open http://127.0.0.1:8000. Stop with Ctrl+C. The SQLite file `emergencyx.db` persists data; tables and demo data are created automatically.
4. Tests: `run_tests.bat` (or `python -m pytest` from the project root with the venv active). Without FastAPI installed, `python -m unittest backend.tests.test_services` still runs the core logic tests. API docs: http://127.0.0.1:8000/docs.

## Local demo accounts (change/remove before any public deployment)
driver1 / driver123 (AMB-101, hospital 1 trips), driver2 / driver123, police1 / police123, hospital1 / hospital123 (hospital 1), admin / admin123.
Try: sign in as driver1 in one window, police1 and hospital1 in private windows; click the map to set an origin, Start Trip, then "Start DEMO movement".
Admin → "Reset Demo" resets only rows flagged `is_demo` (and re-seeds sample history).

## Status
Implemented: roles + backend permission checks, PBKDF2 passwords, signed expiring tokens, trips/alerts/junction status, ETA from route progress, junction ranking by urgency/distance, WebSocket sync (auth required), Leaflet map, OSRM route via backend proxy, stats from DB, persistence.
Simulated: demo GPS movement (labelled DEMO), seed hospitals/junctions/history (labelled DEMO), straight-line route when OSRM fails (labelled SIMULATED, only after you confirm).
Not built: live traffic data, AI/traffic-prediction model, real signal integration, rate limiting, HTTPS/secure cookies (use a reverse proxy), frontend-only `demo.html`, separate AlertAcknowledgments router files.
Privacy: only non-identifying case refs; location history visible to driver/police/admin only. Retention: no automatic deletion yet; delete rows from `trip_locations` manually or via Reset Demo.
